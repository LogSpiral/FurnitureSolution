﻿#if false
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Graphics;
using System;
using System.Collections.Generic;
using Terraria;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;

namespace FurnitureSolution;

public class FurnitureIndexViewer : GlobalTile
{
    public override void PostDraw(int i, int j, int type, SpriteBatch spriteBatch)
    {
        return;
        switch (type)
        {
            case TileID.Platforms:              // 1    | 18x18 | Index:FrameY
            case TileID.WorkBenches:            // 2    | 18x18 | Index:FrameX / 2
            case TileID.Tables:                 // 3    | 18x18 | Index:FrameX / 3
            case TileID.Tables2:                // 4    | 18x18 | Index:FrameX / 3
            case TileID.Chairs:                 // 5    | 18x18 | Index:FrameY / 2
            case TileID.ClosedDoor:             // 6    | 18x18 | Index:FrameY / 3 + FrameX / 3 * 36
            case TileID.Containers:             // 7    | 18x18 | Index:FrameX / 2
            case TileID.Containers2:            // 8    | 18x18 | Index:FrameX / 2
            case TileID.Beds:                   // 9    | 18x18 | Index:FrameY / 2
            case TileID.Bookcases:              // 10   | 18x18 | Index:FrameX / 3 + FrameY / 3 * 37
            case TileID.Bathtubs:               // 11   | 18x18 | Index:FrameY / 2
            case TileID.Candelabras:            // 12   | 18x18 | Index:FrameY / 2
            case TileID.Candles:                // 13   | 18x22 | Index:FrameY
            case TileID.Chandeliers:            // 14   | 18x18 | Index:FrameY / 3 + FrameX / 3 * 37
            case TileID.GrandfatherClocks:      // 15   | 18x18 | Index:FrameX / 2
            case TileID.Dressers:               // 16   | 18x18 | Index:FrameX / 3 + FrameY / 3 * 37
            case TileID.Lamps:                  // 17   | 18x18 | Index:FrameY / 3 + FrameX / 2 * 37
            case TileID.HangingLanterns:        // 18   | 18x18 | Index:FrameY / 2
            case TileID.Pianos:                 // 19   | 18x18 | Index:FrameX / 3 + FrameY / 2 * 37
            case TileID.Sinks:                  // 20   | 18x18 | Index:FrameY / 2
            case TileID.Benches:                // 21   | 18x18 | Index:FrameX / 3
            case TileID.Toilets:                // 22   | 18x18 | Index:FrameY / 2
                {
                    var tile = Framing.GetTileSafely(i, j);
                    if (type == Framing.GetTileSafely(i - 1, j).TileType || type == Framing.GetTileSafely(i, j - 1).TileType) return;
                    Vector2 zero = new(Main.offScreenRange, Main.offScreenRange);
                    if (Main.drawToScreen)
                        zero = Vector2.Zero;
                    spriteBatch.DrawString(
                        FontAssets.MouseText.Value,
                        (tile.TileFrameX / 18, tile.TileFrameY / 18).ToString(),
                        new Vector2(i, j) * 16 - Main.screenPosition + zero,
                        Color.White);

                    if (type == TileID.Chandeliers) Main.NewText(new Vector2(i, j));

                    break;
                }
        }
        base.PostDraw(i, j, type, spriteBatch);
    }

    public override bool PreDraw(int i, int j, int type, SpriteBatch spriteBatch)
    {
        return true;
        switch (type)
        {
            case TileID.Platforms:
            case TileID.WorkBenches:
            case TileID.Tables:
            case TileID.Tables2:
            case TileID.Chairs:
            case TileID.ClosedDoor:
            case TileID.Containers:
            case TileID.Containers2:
            case TileID.Beds:
            case TileID.Bookcases:
            case TileID.Bathtubs:
            case TileID.Candelabras:
            case TileID.Candles:
            case TileID.Chandeliers:
            case TileID.GrandfatherClocks:
            case TileID.Dressers:
            case TileID.Lamps:
            case TileID.HangingLanterns:
            case TileID.Pianos:
            case TileID.Sinks:
            case TileID.Benches:
            case TileID.Toilets:
                {
                    if (type == TileID.Chandeliers)
                    {

                    }
                    var tileL = Framing.GetTileSafely(i - 1, j).TileType;
                    var tileU = Framing.GetTileSafely(i, j - 1).TileType;
                    if (type == tileL || type == tileU) return false;

                    if (type is TileID.Chandeliers or TileID.HangingLanterns or TileID.Toilets)
                    {
                        var tile = Framing.GetTileSafely(i, j);
                        Vector2 zero = new(Main.offScreenRange, Main.offScreenRange);
                        if (Main.drawToScreen)
                            zero = Vector2.Zero;
                        spriteBatch.DrawString(
                            FontAssets.MouseText.Value,
                            (tile.TileFrameX / 18, tile.TileFrameY / 18).ToString(),
                            new Vector2(i, j) * 16 - Main.screenPosition + zero,
                            Color.White);
                    }

                    break;
                }
        }
        return true;
    }
}

public class FurnitureViewPlayer : ModPlayer
{
    public override void PostUpdate()
    {
        if (Main.gameMenu || !Player.controlUseItem) return;
        var tile = Framing.GetTileSafely(Main.MouseWorld.ToTileCoordinates());
        Main.NewText((tile.TileType, tile.TileFrameX / 18f, tile.TileFrameY / 18f, tile.TileFrameNumber));
    }
}


public class FurnitureViewItem : GlobalItem
{
    public override bool? UseItem(Item _item, Player player)
    {
        if (player.itemAnimation == 10)
        {
            //var coord = Main.MouseWorld.ToTileCoordinates();




            //for (int n = 0; n < 10; n++)
            //    WorldGen.PlaceTile(coord.X + n, coord.Y, TileID.WoodBlock, true, true);
            Dictionary<string, List<int>> dataTable = [];
            foreach (var item in ContentSamples.ItemsByType.Values)
            {
                if (item.type == ItemID.WorkBench) continue;
                if (item.createTile == TileID.WorkBenches)
                {
                    var name = item.Name.Replace("工作台", "");
                    if (name == "金色") name = "金";
                    dataTable.Add(name, [item.placeStyle]);
                }
            }
            //dataTable.Add("木", [0]);
            //dataTable.Add("针叶木", []);
            //dataTable.Add("蘑菇", []);
            //dataTable.Add("地牢", []);
            //dataTable.Add("南瓜", []);
            // dataTable.Add("棕榈木", []);
            //dataTable.Add("金", []);

            void FillDictionary(ushort targetType, ushort offset = 0)
            {
                HashSet<string> modifiedList = [.. dataTable.Keys];
                foreach (var item in ContentSamples.ItemsByType.Values)
                {
                    if (item.createTile != targetType) continue;
                    // if (item.Name.Contains("蓝地牢") || item.Name.Contains("粉地牢") || item.Name.Contains("绿地牢")) continue;
                    foreach (var pair in dataTable)
                    {
                        if (!item.Name.Contains(pair.Key)) continue;
                        modifiedList.Remove(pair.Key);
                        if (offset != 0)
                            pair.Value[^1] = item.placeStyle + offset;
                        else
                            pair.Value.Add(item.placeStyle);
                        break;
                    }
                }
                foreach (var name in modifiedList)
                    if (offset == 0)
                        dataTable[name].Add(-1);
            }
            FillDictionary(TileID.Platforms);
            //FillDictionary(TileID.Tables);
            //FillDictionary(TileID.Tables2, 100);
            //FillDictionary(TileID.Chairs);
            //FillDictionary(TileID.ClosedDoor);
            //FillDictionary(TileID.Containers);
            //FillDictionary(TileID.Containers2, 100);
            //FillDictionary(TileID.Beds);
            //FillDictionary(TileID.Bookcases);
            //FillDictionary(TileID.Bathtubs);
            //FillDictionary(TileID.Candelabras);
            //FillDictionary(TileID.Candles);
            //FillDictionary(TileID.Chandeliers);
            //FillDictionary(TileID.GrandfatherClocks);
            //FillDictionary(TileID.Dressers);
            //FillDictionary(TileID.Lamps);
            //FillDictionary(TileID.HangingLanterns);
            //FillDictionary(TileID.Pianos);
            //FillDictionary(TileID.Sinks);
            //FillDictionary(TileID.Benches);
            //FillDictionary(TileID.Toilets);


            foreach (var pair in dataTable)
            {
                Console.Write(pair.Key);
                foreach (var v in pair.Value)
                    Console.Write($" {v},");
                Console.WriteLine();
            }
        }
        return base.UseItem(_item, player);
    }
}
#endif