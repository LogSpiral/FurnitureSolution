﻿using FurnitureSolution.Solutions.Core;
namespace FurnitureSolution.Solutions.LunarSolutions;

public class SolarSolution : SolutionItemBase<SolarSolutionProjectile>;
public class SolarSolutionProjectile() : SolutionProjectileBase(34);
